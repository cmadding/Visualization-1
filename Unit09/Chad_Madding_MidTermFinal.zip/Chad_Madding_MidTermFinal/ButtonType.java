/* From Verlet World Demo 
 By: Ira Greenberg
*/

enum ButtonType {
  RECT, 
    ROUNDED_RECT
};
