/* From Verlet World Demo 
 By: Ira Greenberg
 */

enum Layout {
  LEFT, RIGHT, TOP, BOTTOM
};
